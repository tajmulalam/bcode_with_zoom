package devliving.online.mvbarcodereadersample.models;

public class BarcodeModel {
    private String PrefKeyName;
    private String codeData;

    public BarcodeModel() {
    }

    public String getPrefKeyName() {
        return PrefKeyName;
    }

    public void setPrefKeyName(String prefKeyName) {
        PrefKeyName = prefKeyName;
    }

    public String getCodeData() {
        return codeData;
    }

    public void setCodeData(String codeData) {
        this.codeData = codeData;
    }
}
