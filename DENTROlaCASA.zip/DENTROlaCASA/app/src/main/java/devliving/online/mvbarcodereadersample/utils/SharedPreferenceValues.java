package devliving.online.mvbarcodereadersample.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;

import devliving.online.mvbarcodereadersample.models.BarcodeModel;

/**
 * Created by Md Tajmul Alam on 12/26/2017.
 */

public class SharedPreferenceValues {

    public static void setCodeSavingCount(Context mContext, int count) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("CODE_SAVING_COUNT_DATA", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("CODE_SAVING_COUNT", count);
        editor.commit();

    }

    public static int getCodeSavingCount(Context mContext) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("CODE_SAVING_COUNT_DATA", Context.MODE_PRIVATE);
        return sharedPreferences.getInt("CODE_SAVING_COUNT", 0);
    }

    public static void setCodeData(Context mContext, BarcodeModel barcodeModel, int count) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("CODE_SAVING_DATA", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("data_" + String.valueOf(count), new Gson().toJson(barcodeModel));
        editor.commit();

    }

    public static BarcodeModel getCodeData(Context mContext, int count) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("CODE_SAVING_DATA", Context.MODE_PRIVATE);
        String wifiRecord = sharedPreferences.getString("data_" + String.valueOf(count), "");
        return new Gson().fromJson(wifiRecord, BarcodeModel.class);

    }

    public static void clearCodeData(Context mContext, int count) {
        SharedPreferences sharedPreferences = mContext.getSharedPreferences("CODE_SAVING_DATA", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("data_" + String.valueOf(count));
        editor.commit();
    }

}
