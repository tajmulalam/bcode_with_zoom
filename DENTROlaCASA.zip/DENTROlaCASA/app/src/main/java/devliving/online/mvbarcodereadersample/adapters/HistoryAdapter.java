package devliving.online.mvbarcodereadersample.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.URLUtil;
import android.widget.TextView;

import java.util.List;

import devliving.online.mvbarcodereadersample.R;
import devliving.online.mvbarcodereadersample.models.BarcodeModel;

/**
 * Created by Md Tajmul Alam on 2/26/2018.
 */

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder> {
    private List<BarcodeModel> barcodeModelList;
    private Context mContext;

    public HistoryAdapter(List<BarcodeModel> barcodeModelList, Context mContext) {
        this.barcodeModelList = barcodeModelList;
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public HistoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.history_custom_row, null);
        return new HistoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(HistoryViewHolder holder, final int position) {
        holder.tvCode.setText(barcodeModelList.get(position).getCodeData());
        if (URLUtil.isValidUrl(barcodeModelList.get(position).getCodeData())) {
            holder.tvCode.setTextColor(Color.BLUE);
            holder.tvCode.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Intent.ACTION_VIEW,
                            Uri.parse(barcodeModelList.get(position).getCodeData()));
                    mContext.startActivity(i);
                }
            });
        } else {
            holder.tvCode.setTextColor(Color.BLACK);
            holder.tvCode.setOnClickListener(null);
        }
    }


    @Override
    public int getItemCount() {
        return barcodeModelList != null ? barcodeModelList.size() : 0;
    }

    public class HistoryViewHolder extends RecyclerView.ViewHolder {
        private TextView tvCode;
//        private ImageView ivCrown;

        public HistoryViewHolder(View itemView) {
            super(itemView);
            tvCode = itemView.findViewById(R.id.tvCode);

        }
    }
}
