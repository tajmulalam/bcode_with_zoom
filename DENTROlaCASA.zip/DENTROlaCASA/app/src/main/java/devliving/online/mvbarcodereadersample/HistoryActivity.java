package devliving.online.mvbarcodereadersample;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import devliving.online.mvbarcodereadersample.adapters.HistoryAdapter;
import devliving.online.mvbarcodereadersample.models.BarcodeModel;
import devliving.online.mvbarcodereadersample.utils.SharedPreferenceValues;

public class HistoryActivity extends Activity {
    RecyclerView rvHistory;
    List<BarcodeModel> barcodeModelList;
    HistoryAdapter adapter;
    Button btnClearAll, btnBack;
TextView emptyView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        barcodeModelList = new ArrayList<>();
        rvHistory = findViewById(R.id.rvHistory);
        btnClearAll = findViewById(R.id.btnClearAll);
        emptyView = findViewById(R.id.empty_view);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(HistoryActivity.this);
        rvHistory.setLayoutManager(layoutManager);
        loadData();
        btnClearAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearCodeData();
            }
        });
        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        finish();
    }

    private void clearCodeData() {
        for (int i = 0; i <= SharedPreferenceValues.getCodeSavingCount(HistoryActivity.this); i++) {
            int index = i + 1;
            SharedPreferenceValues.clearCodeData(HistoryActivity.this, index);
        }
        SharedPreferenceValues.setCodeSavingCount(HistoryActivity.this, 0);
        loadData();
    }

    public void loadData() {
        barcodeModelList.clear();
        for (int i = 0; i <= SharedPreferenceValues.getCodeSavingCount(HistoryActivity.this); i++) {
            BarcodeModel barcodeModel = SharedPreferenceValues.getCodeData(HistoryActivity.this, i + 1);
            if (barcodeModel != null) {
                barcodeModelList.add(barcodeModel);
            }
        }
        if (barcodeModelList.size() > 0) {
            rvHistory.setVisibility(View.VISIBLE);
            emptyView.setVisibility(View.GONE);
            loadAdapter();
        }else {
            rvHistory.setVisibility(View.GONE);
            emptyView.setVisibility(View.VISIBLE);
        }
    }

    private void loadAdapter() {
        adapter = new HistoryAdapter(barcodeModelList, HistoryActivity.this);
        rvHistory.setAdapter(adapter);
    }

}
