package devliving.online.mvbarcodereadersample;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.webkit.URLUtil;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.vision.barcode.Barcode;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import devliving.online.mvbarcodereader.MVBarcodeScanner;
import devliving.online.mvbarcodereadersample.models.BarcodeModel;
import devliving.online.mvbarcodereadersample.utils.SharedPreferenceValues;

public class MainActivity extends Activity implements View.OnClickListener {

    final int REQ_CODE = 12;

    TextView result;
    RelativeLayout scanButton;

    @MVBarcodeScanner.BarCodeFormat
    int[] mFormats = null;

    Barcode mBarcode;
    List<Barcode> mBarcodes;

    final static HashMap<Integer, String> TYPE_MAP;
    final static String[] barcodeTypeItems;

    static {
        TYPE_MAP = new HashMap<>();

        TYPE_MAP.put(Barcode.ALL_FORMATS, "All Formats");
        TYPE_MAP.put(Barcode.AZTEC, "Aztec");
        TYPE_MAP.put(Barcode.CALENDAR_EVENT, "Calendar Event");
        TYPE_MAP.put(Barcode.CODABAR, "Codabar");
        TYPE_MAP.put(Barcode.CODE_39, "Code 39");
        TYPE_MAP.put(Barcode.CODE_93, "Code 93");
        TYPE_MAP.put(Barcode.CODE_128, "Code 128");
        TYPE_MAP.put(Barcode.CONTACT_INFO, "Contact Info");
        TYPE_MAP.put(Barcode.DATA_MATRIX, "Data Matrix");
        TYPE_MAP.put(Barcode.DRIVER_LICENSE, "Drivers License");
        TYPE_MAP.put(Barcode.EAN_8, "EAN 8");
        TYPE_MAP.put(Barcode.EAN_13, "EAN 13");
        TYPE_MAP.put(Barcode.EMAIL, "Email");
        TYPE_MAP.put(Barcode.GEO, "Geo");
        TYPE_MAP.put(Barcode.ISBN, "ISBN");
        TYPE_MAP.put(Barcode.ITF, "ITF");
        TYPE_MAP.put(Barcode.PDF417, "PDF 417");
        TYPE_MAP.put(Barcode.PHONE, "Phone");
        TYPE_MAP.put(Barcode.QR_CODE, "QR Code");
        TYPE_MAP.put(Barcode.PRODUCT, "Product");
        TYPE_MAP.put(Barcode.SMS, "SMS");
        TYPE_MAP.put(Barcode.UPC_A, "UPC A");
        TYPE_MAP.put(Barcode.UPC_E, "UPC E");
        TYPE_MAP.put(Barcode.TEXT, "Text");
        TYPE_MAP.put(Barcode.URL, "URL");

        List<String> items = new ArrayList<>(TYPE_MAP.values());
        Collections.sort(items);
        String[] tempArray = new String[items.size()];
        tempArray = items.toArray(tempArray);
        barcodeTypeItems = tempArray;
    }

    private Button btnHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        result = (TextView) findViewById(R.id.result);
        scanButton = (RelativeLayout) findViewById(R.id.scan);
        btnHistory = findViewById(R.id.btnHistory);
        result.setMovementMethod(new ScrollingMovementMethod());
        scanButton.setOnClickListener(this);
        result.setVisibility(View.GONE);
        btnHistory.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == scanButton.getId()) {
            new MVBarcodeScanner.Builder()
                    .setScanningMode(MVBarcodeScanner.ScanningMode.SINGLE_AUTO)
                    .setFormats(mFormats)
                    .build()
                    .launchScanner(this, REQ_CODE);

            //Intent intent = new Intent(this, IssueDebugActivity.class);
            //startActivity(intent);
        }
        if (view.getId() == btnHistory.getId()) {
            startActivity(new Intent(MainActivity.this, HistoryActivity.class));

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_CODE) {
            result.setVisibility(View.VISIBLE);
            if (resultCode == RESULT_OK && data != null
                    && data.getExtras() != null) {
                Log.d("BARCODE-SCANNER", "onActivityResult inside block called");
                if (data.getExtras().containsKey(MVBarcodeScanner.BarcodeObject)) {
                    mBarcode = data.getParcelableExtra(MVBarcodeScanner.BarcodeObject);
                    mBarcodes = null;
                } else if (data.getExtras().containsKey(MVBarcodeScanner.BarcodeObjects)) {
                    mBarcodes = data.getParcelableArrayListExtra(MVBarcodeScanner.BarcodeObjects);
                    mBarcode = null;
                }
                updateBarcodeInfo();
            } else {
                mBarcode = null;
                mBarcodes = null;
                updateBarcodeInfo();
            }
        }
    }

    void updateBarcodeInfo() {
        StringBuilder builder = new StringBuilder();

        if (mBarcode != null) {
            Log.d("BARCODE-SCANNER", "got barcode");
            /*builder.append("Type: " + getBarcodeFormatName(mBarcode.format) +
                    "\nData: " + mBarcode.rawValue + "\n\n");*/

            builder.append(mBarcode.rawValue);
        }

        if (mBarcodes != null) {
            Log.d("BARCODE-SCANNER", "got barcodes");
            for (Barcode barcode : mBarcodes) {
              /*  builder.append("Type: " + getBarcodeFormatName(barcode.format) +
                        "\nData: " + barcode.rawValue + "\n\n");*/

                builder.append(barcode.rawValue + "\n\n");
            }
        }

        if (builder.length() > 0) {
            result.setText(builder.toString());
            saveCodeData(result.getText().toString());
            if (URLUtil.isValidUrl(result.getText().toString())) {
                result.setTextColor(Color.BLUE);
                result.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(Intent.ACTION_VIEW,
                                Uri.parse(result.getText().toString()));
                        startActivity(i);
                    }
                });
                result.performClick();
            }
        } else {
            result.setText("");
            result.setTextColor(Color.BLACK);
            result.setOnClickListener(null);
        }
    }

    int count = 0;

    private void saveCodeData(String codeData) {
        count = SharedPreferenceValues.getCodeSavingCount(MainActivity.this) + 1;
        BarcodeModel barcodeModel = new BarcodeModel();
        barcodeModel.setPrefKeyName("data_" + String.valueOf(count));
        barcodeModel.setCodeData(codeData);
        SharedPreferenceValues.setCodeData(MainActivity.this, barcodeModel, count);
        SharedPreferenceValues.setCodeSavingCount(MainActivity.this, count);

    }

    String getBarcodeFormatName(int format) {
        return TYPE_MAP.get(format);
    }
}
